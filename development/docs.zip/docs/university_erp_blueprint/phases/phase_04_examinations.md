# Phase 4: Examinations & Results

## Overview

**Duration:** 5-6 weeks
**Priority:** High - Academic evaluation system
**Module Focus:** Assessment extensions, Exam scheduling, Hall tickets, Grading, CGPA calculation, Transcripts

This phase implements the complete examination system by extending Frappe Education's Assessment Plan and Assessment Result DocTypes while adding university-specific features like hall tickets, seating arrangements, moderation, and transcripts.

---

## Prerequisites

### From Previous Phases
- [ ] Phase 1-3 complete (students enrolled, courses assigned)
- [ ] Assessment Result DocType extended with grading fields
- [ ] Course enrollments active
- [ ] Attendance tracking functional (for eligibility)
- [ ] L-T-P-S credits on courses configured

### Technical Requirements
- [ ] Education module's Assessment Plan DocType accessible
- [ ] Education module's Assessment Result DocType accessible
- [ ] Grading Scale DocType configured
- [ ] PDF generation capability

### Data Requirements
- [ ] Grading scale defined (10-point CBCS)
- [ ] Exam fee structure
- [ ] Examination rooms identified
- [ ] Invigilation duty roster ready

---

## Deliverables

### Week 1-2: Assessment Extensions

#### 1.1 Assessment Result Override

**File:** `university_erp/overrides/assessment_result.py`
```python
from education.education.doctype.assessment_result.assessment_result import AssessmentResult
import frappe
from frappe.utils import flt

class UniversityAssessmentResult(AssessmentResult):
    """Extended Assessment Result for university grading"""

    # 10-point CBCS Grading Scale
    GRADING_SCALE = [
        {"min": 90, "max": 100, "grade": "O", "grade_points": 10, "description": "Outstanding"},
        {"min": 80, "max": 89.99, "grade": "A+", "grade_points": 9, "description": "Excellent"},
        {"min": 70, "max": 79.99, "grade": "A", "grade_points": 8, "description": "Very Good"},
        {"min": 60, "max": 69.99, "grade": "B+", "grade_points": 7, "description": "Good"},
        {"min": 55, "max": 59.99, "grade": "B", "grade_points": 6, "description": "Above Average"},
        {"min": 50, "max": 54.99, "grade": "C", "grade_points": 5, "description": "Average"},
        {"min": 40, "max": 49.99, "grade": "P", "grade_points": 4, "description": "Pass"},
        {"min": 0, "max": 39.99, "grade": "F", "grade_points": 0, "description": "Fail"},
    ]

    def validate(self):
        super().validate()
        self.validate_attendance_eligibility()
        self.calculate_total_marks()
        self.calculate_grade()
        self.calculate_credit_points()

    def validate_attendance_eligibility(self):
        """Check if student was eligible to appear"""
        if self.custom_attendance_percentage:
            min_required = frappe.db.get_value("Course", self.course, "custom_min_attendance") or 75
            if flt(self.custom_attendance_percentage) < min_required:
                if not self.custom_eligibility_waiver:
                    frappe.msgprint(
                        f"Warning: Student attendance ({self.custom_attendance_percentage}%) "
                        f"is below required ({min_required}%)"
                    )

    def calculate_total_marks(self):
        """Calculate total marks from components"""
        if self.details:
            internal_total = 0
            external_total = 0

            for detail in self.details:
                if detail.assessment_criteria:
                    criteria_type = frappe.db.get_value(
                        "Assessment Criteria",
                        detail.assessment_criteria,
                        "custom_criteria_type"
                    )
                    if criteria_type == "Internal":
                        internal_total += flt(detail.score)
                    else:
                        external_total += flt(detail.score)

            self.custom_internal_marks = internal_total
            self.custom_external_marks = external_total

    def calculate_grade(self):
        """Calculate grade from total score using 10-point scale"""
        if not self.total_score or not self.maximum_score:
            return

        percentage = (flt(self.total_score) / flt(self.maximum_score)) * 100
        self.custom_percentage = round(percentage, 2)

        # Get grade from scale
        for interval in self.GRADING_SCALE:
            if interval["min"] <= percentage <= interval["max"]:
                self.custom_grade = interval["grade"]
                self.custom_grade_points = interval["grade_points"]
                break
        else:
            self.custom_grade = "F"
            self.custom_grade_points = 0

        # Determine pass/fail
        self.custom_result_status = "Pass" if self.custom_grade_points >= 4 else "Fail"

        # Check for grace marks/moderation
        if self.custom_grace_marks_applied and self.custom_grace_marks_applied > 0:
            self.custom_moderation_applied = 1

    def calculate_credit_points(self):
        """Calculate credit points (grade_points * credits)"""
        credits = frappe.db.get_value("Course", self.course, "custom_credits") or 0
        self.custom_credits = credits
        self.custom_credit_points = flt(self.custom_grade_points) * flt(credits)

    def on_submit(self):
        super().on_submit()
        self.update_student_cgpa()

    def update_student_cgpa(self):
        """Update student's CGPA after result submission"""
        if self.custom_result_status != "Pass":
            return

        # Recalculate CGPA
        results = frappe.get_all(
            "Assessment Result",
            filters={
                "student": self.student,
                "docstatus": 1,
                "custom_result_status": "Pass"
            },
            fields=["custom_credit_points", "custom_credits"]
        )

        if not results:
            return

        total_credit_points = sum(flt(r.custom_credit_points) for r in results)
        total_credits = sum(flt(r.custom_credits) for r in results)

        cgpa = round(total_credit_points / total_credits, 2) if total_credits else 0

        frappe.db.set_value("Student", self.student, {
            "custom_cgpa": cgpa,
            "custom_total_credits_earned": total_credits
        })
```

#### 1.2 Custom Fields on Assessment Result

```json
[
    {
        "dt": "Assessment Result",
        "fieldname": "custom_exam_section",
        "fieldtype": "Section Break",
        "label": "Examination Details",
        "insert_after": "academic_term"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_exam_type",
        "fieldtype": "Select",
        "label": "Exam Type",
        "options": "Mid Semester\nEnd Semester\nSupplementary\nImprovement",
        "insert_after": "custom_exam_section"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_hall_ticket",
        "fieldtype": "Link",
        "label": "Hall Ticket",
        "options": "Hall Ticket",
        "insert_after": "custom_exam_type"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_attendance_percentage",
        "fieldtype": "Float",
        "label": "Attendance %",
        "read_only": 1,
        "insert_after": "custom_hall_ticket"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_eligibility_waiver",
        "fieldtype": "Check",
        "label": "Eligibility Waiver Granted",
        "insert_after": "custom_attendance_percentage"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_marks_section",
        "fieldtype": "Section Break",
        "label": "Marks Breakdown",
        "insert_after": "maximum_score"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_internal_marks",
        "fieldtype": "Float",
        "label": "Internal Marks",
        "read_only": 1,
        "insert_after": "custom_marks_section"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_external_marks",
        "fieldtype": "Float",
        "label": "External Marks",
        "read_only": 1,
        "insert_after": "custom_internal_marks"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_practical_marks",
        "fieldtype": "Float",
        "label": "Practical Marks",
        "insert_after": "custom_external_marks"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_grade_section",
        "fieldtype": "Section Break",
        "label": "Grade Details",
        "insert_after": "total_score"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_percentage",
        "fieldtype": "Float",
        "label": "Percentage",
        "precision": 2,
        "read_only": 1,
        "insert_after": "custom_grade_section"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_grade",
        "fieldtype": "Data",
        "label": "Grade",
        "read_only": 1,
        "insert_after": "custom_percentage"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_grade_points",
        "fieldtype": "Float",
        "label": "Grade Points",
        "precision": 1,
        "read_only": 1,
        "insert_after": "custom_grade"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_credits",
        "fieldtype": "Float",
        "label": "Course Credits",
        "read_only": 1,
        "insert_after": "custom_grade_points"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_credit_points",
        "fieldtype": "Float",
        "label": "Credit Points",
        "description": "Grade Points x Credits",
        "read_only": 1,
        "insert_after": "custom_credits"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_result_status",
        "fieldtype": "Select",
        "label": "Result Status",
        "options": "Pass\nFail\nAbsent\nWithheld\nCancelled",
        "read_only": 1,
        "insert_after": "custom_credit_points"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_moderation_section",
        "fieldtype": "Section Break",
        "label": "Moderation",
        "insert_after": "custom_result_status"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_original_marks",
        "fieldtype": "Float",
        "label": "Original Marks",
        "permlevel": 2,
        "insert_after": "custom_moderation_section"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_grace_marks_applied",
        "fieldtype": "Float",
        "label": "Grace Marks Applied",
        "permlevel": 2,
        "insert_after": "custom_original_marks"
    },
    {
        "dt": "Assessment Result",
        "fieldname": "custom_moderation_applied",
        "fieldtype": "Check",
        "label": "Moderation Applied",
        "read_only": 1,
        "insert_after": "custom_grace_marks_applied"
    }
]
```

### Week 2-3: Examination Management

#### 2.1 Hall Ticket DocType

```json
{
    "doctype": "DocType",
    "name": "Hall Ticket",
    "module": "Examinations",
    "is_submittable": 1,
    "fields": [
        {"fieldname": "student", "fieldtype": "Link", "options": "Student", "reqd": 1},
        {"fieldname": "student_name", "fieldtype": "Data", "fetch_from": "student.student_name", "read_only": 1},
        {"fieldname": "enrollment_number", "fieldtype": "Data", "fetch_from": "student.custom_enrollment_number", "read_only": 1},
        {"fieldname": "program", "fieldtype": "Link", "options": "Program", "read_only": 1},
        {"fieldname": "photo", "fieldtype": "Attach Image"},

        {"fieldname": "exam_details", "fieldtype": "Section Break"},
        {"fieldname": "academic_term", "fieldtype": "Link", "options": "Academic Term", "reqd": 1},
        {"fieldname": "exam_type", "fieldtype": "Select",
         "options": "Mid Semester\nEnd Semester\nSupplementary\nImprovement", "reqd": 1},
        {"fieldname": "issue_date", "fieldtype": "Date", "default": "Today"},
        {"fieldname": "valid_from", "fieldtype": "Date"},
        {"fieldname": "valid_till", "fieldtype": "Date"},

        {"fieldname": "eligibility_section", "fieldtype": "Section Break"},
        {"fieldname": "overall_attendance", "fieldtype": "Float", "read_only": 1},
        {"fieldname": "fees_cleared", "fieldtype": "Check", "label": "Exam Fees Cleared"},
        {"fieldname": "no_dues", "fieldtype": "Check", "label": "No Dues Certificate"},
        {"fieldname": "is_eligible", "fieldtype": "Check", "read_only": 1},
        {"fieldname": "eligibility_remarks", "fieldtype": "Small Text"},

        {"fieldname": "exams", "fieldtype": "Table", "options": "Hall Ticket Exam"},

        {"fieldname": "qr_code", "fieldtype": "Attach Image", "label": "QR Code", "read_only": 1},
        {"fieldname": "verification_code", "fieldtype": "Data", "read_only": 1}
    ],
    "autoname": "naming_series:HT-.YYYY.-.#####"
}
```

#### 2.2 Hall Ticket Exam Child Table

```json
{
    "doctype": "DocType",
    "name": "Hall Ticket Exam",
    "module": "Examinations",
    "istable": 1,
    "fields": [
        {"fieldname": "course", "fieldtype": "Link", "options": "Course", "reqd": 1, "in_list_view": 1},
        {"fieldname": "course_code", "fieldtype": "Data", "fetch_from": "course.custom_course_code", "in_list_view": 1},
        {"fieldname": "exam_date", "fieldtype": "Date", "in_list_view": 1},
        {"fieldname": "exam_time", "fieldtype": "Time", "in_list_view": 1},
        {"fieldname": "venue", "fieldtype": "Data", "in_list_view": 1},
        {"fieldname": "seat_number", "fieldtype": "Data"},
        {"fieldname": "attendance_percentage", "fieldtype": "Float"},
        {"fieldname": "is_eligible", "fieldtype": "Check", "default": 1}
    ]
}
```

#### 2.3 Hall Ticket Generator

**File:** `university_erp/examinations/hall_ticket.py`
```python
import frappe
import qrcode
import io
import base64
from university_erp.academics.attendance import AttendanceManager

class HallTicketGenerator:
    """Generate hall tickets for examinations"""

    def __init__(self, academic_term, exam_type):
        self.academic_term = academic_term
        self.exam_type = exam_type
        self.attendance_manager = AttendanceManager()

    def generate_for_student(self, student):
        """Generate hall ticket for a single student"""
        student_doc = frappe.get_doc("Student", student)

        # Check if hall ticket already exists
        existing = frappe.db.exists("Hall Ticket", {
            "student": student,
            "academic_term": self.academic_term,
            "exam_type": self.exam_type,
            "docstatus": ["<", 2]
        })

        if existing:
            return existing

        # Get enrolled courses
        enrollments = frappe.get_all(
            "Course Enrollment",
            filters={"student": student, "academic_term": self.academic_term},
            pluck="course"
        )

        if not enrollments:
            frappe.throw(f"No course enrollments found for {student}")

        # Create hall ticket
        hall_ticket = frappe.new_doc("Hall Ticket")
        hall_ticket.student = student
        hall_ticket.program = student_doc.custom_program
        hall_ticket.photo = student_doc.image
        hall_ticket.academic_term = self.academic_term
        hall_ticket.exam_type = self.exam_type

        # Check eligibility and add exams
        total_attendance = 0
        eligible_count = 0

        for course in enrollments:
            eligibility = self.attendance_manager.check_exam_eligibility(
                student, course, self.academic_term
            )

            exam_schedule = self.get_exam_schedule(course)

            hall_ticket.append("exams", {
                "course": course,
                "exam_date": exam_schedule.get("date") if exam_schedule else None,
                "exam_time": exam_schedule.get("time") if exam_schedule else None,
                "venue": exam_schedule.get("venue") if exam_schedule else None,
                "attendance_percentage": eligibility["percentage"],
                "is_eligible": eligibility["eligible"]
            })

            total_attendance += eligibility["percentage"]
            if eligibility["eligible"]:
                eligible_count += 1

        # Calculate overall eligibility
        hall_ticket.overall_attendance = round(total_attendance / len(enrollments), 2) if enrollments else 0
        hall_ticket.fees_cleared = self.check_fees_cleared(student)
        hall_ticket.no_dues = self.check_no_dues(student)
        hall_ticket.is_eligible = eligible_count > 0 and hall_ticket.fees_cleared

        # Generate verification code and QR
        hall_ticket.verification_code = self.generate_verification_code(hall_ticket)
        hall_ticket.qr_code = self.generate_qr_code(hall_ticket)

        hall_ticket.insert()
        return hall_ticket.name

    def generate_for_program(self, program):
        """Generate hall tickets for all students in a program"""
        students = frappe.get_all(
            "Student",
            filters={
                "custom_program": program,
                "custom_student_status": "Active"
            },
            pluck="name"
        )

        generated = []
        failed = []

        for student in students:
            try:
                ht = self.generate_for_student(student)
                generated.append(ht)
            except Exception as e:
                failed.append({"student": student, "error": str(e)})

        return {"generated": generated, "failed": failed}

    def get_exam_schedule(self, course):
        """Get exam schedule for a course"""
        schedule = frappe.db.get_value(
            "Exam Schedule",
            {
                "course": course,
                "academic_term": self.academic_term,
                "exam_type": self.exam_type
            },
            ["exam_date", "from_time", "venue"],
            as_dict=True
        )

        if schedule:
            return {
                "date": schedule.exam_date,
                "time": schedule.from_time,
                "venue": schedule.venue
            }
        return None

    def check_fees_cleared(self, student):
        """Check if exam fees are cleared"""
        pending = frappe.db.exists(
            "Fees",
            {
                "student": student,
                "outstanding_amount": [">", 0],
                "custom_fee_type": "Examination Fee"
            }
        )
        return not pending

    def check_no_dues(self, student):
        """Check for library and other dues"""
        # Check library dues
        library_dues = frappe.db.exists(
            "Library Transaction",
            {
                "custom_student": student,
                "type": "Issue",
                "docstatus": 1
            }
        )
        return not library_dues

    def generate_verification_code(self, hall_ticket):
        """Generate unique verification code"""
        import hashlib
        data = f"{hall_ticket.student}{hall_ticket.academic_term}{frappe.utils.now()}"
        return hashlib.sha256(data.encode()).hexdigest()[:12].upper()

    def generate_qr_code(self, hall_ticket):
        """Generate QR code for hall ticket"""
        qr_data = {
            "student": hall_ticket.student,
            "enrollment": hall_ticket.enrollment_number,
            "code": hall_ticket.verification_code
        }

        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(frappe.as_json(qr_data))
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")

        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        img_str = base64.b64encode(buffer.getvalue()).decode()

        # Save as file
        file_name = f"qr_{hall_ticket.student}_{hall_ticket.verification_code}.png"
        file_doc = frappe.get_doc({
            "doctype": "File",
            "file_name": file_name,
            "content": buffer.getvalue(),
            "is_private": 1
        })
        file_doc.save(ignore_permissions=True)

        return file_doc.file_url


@frappe.whitelist()
def generate_hall_ticket(student, academic_term, exam_type):
    """API to generate hall ticket"""
    generator = HallTicketGenerator(academic_term, exam_type)
    return generator.generate_for_student(student)

@frappe.whitelist()
def bulk_generate_hall_tickets(program, academic_term, exam_type):
    """API to bulk generate hall tickets"""
    generator = HallTicketGenerator(academic_term, exam_type)
    return generator.generate_for_program(program)
```

### Week 3-4: Result Processing

#### 3.1 Exam Schedule DocType

```json
{
    "doctype": "DocType",
    "name": "Exam Schedule",
    "module": "Examinations",
    "fields": [
        {"fieldname": "academic_term", "fieldtype": "Link", "options": "Academic Term", "reqd": 1},
        {"fieldname": "exam_type", "fieldtype": "Select",
         "options": "Mid Semester\nEnd Semester\nSupplementary\nImprovement", "reqd": 1},
        {"fieldname": "course", "fieldtype": "Link", "options": "Course", "reqd": 1},
        {"fieldname": "course_name", "fieldtype": "Data", "fetch_from": "course.course_name", "read_only": 1},
        {"fieldname": "exam_date", "fieldtype": "Date", "reqd": 1},
        {"fieldname": "from_time", "fieldtype": "Time", "reqd": 1},
        {"fieldname": "to_time", "fieldtype": "Time", "reqd": 1},
        {"fieldname": "duration_minutes", "fieldtype": "Int"},
        {"fieldname": "venue", "fieldtype": "Link", "options": "University Classroom"},
        {"fieldname": "max_marks", "fieldtype": "Int", "default": 100},
        {"fieldname": "passing_marks", "fieldtype": "Int", "default": 40},
        {"fieldname": "invigilators", "fieldtype": "Table MultiSelect", "options": "Exam Invigilator"}
    ]
}
```

#### 3.2 Result Entry Tool

**File:** `university_erp/examinations/result_entry.py`
```python
import frappe
from frappe.utils import flt

class ResultEntryTool:
    """Bulk result entry for examinations"""

    def __init__(self, course, academic_term, exam_type):
        self.course = course
        self.academic_term = academic_term
        self.exam_type = exam_type
        self.assessment_plan = self.get_or_create_assessment_plan()

    def get_or_create_assessment_plan(self):
        """Get or create assessment plan for this exam"""
        existing = frappe.db.exists("Assessment Plan", {
            "course": self.course,
            "academic_term": self.academic_term,
            "custom_exam_type": self.exam_type
        })

        if existing:
            return existing

        # Create new assessment plan
        plan = frappe.new_doc("Assessment Plan")
        plan.course = self.course
        plan.academic_term = self.academic_term
        plan.custom_exam_type = self.exam_type
        plan.maximum_assessment_score = 100
        plan.insert(ignore_permissions=True)

        return plan.name

    def get_students_for_entry(self):
        """Get list of students for result entry"""
        # Get students with hall tickets for this course
        hall_tickets = frappe.get_all(
            "Hall Ticket",
            filters={
                "academic_term": self.academic_term,
                "exam_type": self.exam_type,
                "docstatus": 1
            },
            pluck="name"
        )

        students = []
        for ht in hall_tickets:
            exams = frappe.get_all(
                "Hall Ticket Exam",
                filters={"parent": ht, "course": self.course, "is_eligible": 1},
                fields=["parent"]
            )

            if exams:
                student = frappe.db.get_value("Hall Ticket", ht, "student")
                student_doc = frappe.get_doc("Student", student)
                students.append({
                    "student": student,
                    "student_name": student_doc.student_name,
                    "enrollment_number": student_doc.custom_enrollment_number,
                    "hall_ticket": ht
                })

        return students

    def save_results(self, results_data):
        """Save results for multiple students"""
        saved = []
        errors = []

        for result in results_data:
            try:
                self.save_single_result(result)
                saved.append(result["student"])
            except Exception as e:
                errors.append({"student": result["student"], "error": str(e)})

        return {"saved": saved, "errors": errors}

    def save_single_result(self, result_data):
        """Save result for single student"""
        student = result_data.get("student")

        # Check if result already exists
        existing = frappe.db.exists("Assessment Result", {
            "student": student,
            "assessment_plan": self.assessment_plan
        })

        if existing:
            result = frappe.get_doc("Assessment Result", existing)
        else:
            result = frappe.new_doc("Assessment Result")
            result.student = student
            result.assessment_plan = self.assessment_plan
            result.course = self.course
            result.academic_term = self.academic_term

        # Set marks
        result.total_score = flt(result_data.get("total_score", 0))
        result.maximum_score = flt(result_data.get("maximum_score", 100))
        result.custom_exam_type = self.exam_type
        result.custom_internal_marks = flt(result_data.get("internal_marks", 0))
        result.custom_external_marks = flt(result_data.get("external_marks", 0))
        result.custom_practical_marks = flt(result_data.get("practical_marks", 0))
        result.custom_hall_ticket = result_data.get("hall_ticket")

        # Handle absent/withheld
        if result_data.get("status") == "Absent":
            result.custom_result_status = "Absent"
            result.total_score = 0
        elif result_data.get("status") == "Withheld":
            result.custom_result_status = "Withheld"

        result.save(ignore_permissions=True)
        return result.name

    def apply_moderation(self, moderation_percentage=None, grace_marks=None):
        """Apply moderation to results"""
        results = frappe.get_all(
            "Assessment Result",
            filters={
                "assessment_plan": self.assessment_plan,
                "docstatus": 0
            },
            pluck="name"
        )

        for result_name in results:
            result = frappe.get_doc("Assessment Result", result_name)

            # Store original marks
            if not result.custom_original_marks:
                result.custom_original_marks = result.total_score

            # Apply moderation
            if moderation_percentage:
                moderated = result.custom_original_marks * (1 + moderation_percentage / 100)
                result.total_score = min(moderated, result.maximum_score)
            elif grace_marks:
                result.total_score = min(
                    result.custom_original_marks + grace_marks,
                    result.maximum_score
                )

            result.custom_grace_marks_applied = result.total_score - result.custom_original_marks
            result.save(ignore_permissions=True)

        return len(results)


@frappe.whitelist()
def get_students_for_result_entry(course, academic_term, exam_type):
    """API to get students for result entry"""
    tool = ResultEntryTool(course, academic_term, exam_type)
    return tool.get_students_for_entry()

@frappe.whitelist()
def save_exam_results(course, academic_term, exam_type, results_data):
    """API to save exam results"""
    if isinstance(results_data, str):
        results_data = frappe.parse_json(results_data)

    tool = ResultEntryTool(course, academic_term, exam_type)
    return tool.save_results(results_data)

@frappe.whitelist()
def apply_result_moderation(course, academic_term, exam_type, moderation_percentage=None, grace_marks=None):
    """API to apply moderation"""
    tool = ResultEntryTool(course, academic_term, exam_type)
    return tool.apply_moderation(flt(moderation_percentage), flt(grace_marks))
```

### Week 4-5: Transcripts & Grade Cards

#### 4.1 Student Transcript DocType

```json
{
    "doctype": "DocType",
    "name": "Student Transcript",
    "module": "Examinations",
    "is_submittable": 1,
    "fields": [
        {"fieldname": "student", "fieldtype": "Link", "options": "Student", "reqd": 1},
        {"fieldname": "student_name", "fieldtype": "Data", "fetch_from": "student.student_name", "read_only": 1},
        {"fieldname": "enrollment_number", "fieldtype": "Data", "fetch_from": "student.custom_enrollment_number", "read_only": 1},
        {"fieldname": "program", "fieldtype": "Link", "options": "Program"},
        {"fieldname": "program_name", "fieldtype": "Data", "fetch_from": "program.program_name", "read_only": 1},

        {"fieldname": "transcript_type", "fieldtype": "Select",
         "options": "Provisional\nFinal\nDuplicate", "default": "Provisional"},
        {"fieldname": "generated_date", "fieldtype": "Date", "default": "Today"},
        {"fieldname": "purpose", "fieldtype": "Data"},

        {"fieldname": "academic_summary", "fieldtype": "Section Break"},
        {"fieldname": "cgpa", "fieldtype": "Float", "precision": 2, "read_only": 1},
        {"fieldname": "total_credits_earned", "fieldtype": "Int", "read_only": 1},
        {"fieldname": "total_credits_required", "fieldtype": "Int", "read_only": 1},
        {"fieldname": "degree_class", "fieldtype": "Data", "read_only": 1},

        {"fieldname": "semester_results", "fieldtype": "Table", "options": "Transcript Semester Result"},

        {"fieldname": "verification_section", "fieldtype": "Section Break"},
        {"fieldname": "transcript_number", "fieldtype": "Data", "read_only": 1},
        {"fieldname": "qr_code", "fieldtype": "Attach Image", "read_only": 1},
        {"fieldname": "digital_signature", "fieldtype": "Attach", "read_only": 1}
    ],
    "autoname": "naming_series:TR-.YYYY.-.#####"
}
```

#### 4.2 Transcript Generator

**File:** `university_erp/examinations/transcript.py`
```python
import frappe
from frappe.utils import flt
from frappe.utils.pdf import get_pdf

class TranscriptGenerator:
    """Generate official student transcripts"""

    DEGREE_CLASSIFICATIONS = [
        {"min_cgpa": 9.0, "class": "First Class with Distinction"},
        {"min_cgpa": 7.5, "class": "First Class"},
        {"min_cgpa": 6.0, "class": "Second Class"},
        {"min_cgpa": 4.0, "class": "Pass"},
        {"min_cgpa": 0, "class": "Incomplete"},
    ]

    def __init__(self, student):
        self.student = frappe.get_doc("Student", student)
        self.results = self.get_all_results()

    def get_all_results(self):
        """Get all assessment results for student"""
        return frappe.get_all(
            "Assessment Result",
            filters={"student": self.student.name, "docstatus": 1},
            fields=[
                "name", "course", "academic_term", "total_score", "maximum_score",
                "custom_grade", "custom_grade_points", "custom_credits",
                "custom_credit_points", "custom_result_status", "custom_percentage"
            ],
            order_by="academic_term asc, course asc"
        )

    def generate_transcript(self, transcript_type="Provisional", purpose=None):
        """Generate official transcript document"""
        # Calculate CGPA and organize data
        semester_data = self.organize_by_semester()
        cgpa = self.calculate_cgpa()
        total_credits = self.calculate_total_credits()
        degree_class = self.determine_degree_class(cgpa)

        # Get program credits requirement
        program = frappe.get_doc("Program", self.student.custom_program)
        required_credits = program.custom_min_credits_graduation or 0

        # Create transcript document
        transcript = frappe.new_doc("Student Transcript")
        transcript.student = self.student.name
        transcript.program = self.student.custom_program
        transcript.transcript_type = transcript_type
        transcript.purpose = purpose
        transcript.cgpa = cgpa
        transcript.total_credits_earned = total_credits
        transcript.total_credits_required = required_credits
        transcript.degree_class = degree_class

        # Add semester results
        for term, data in semester_data.items():
            transcript.append("semester_results", {
                "academic_term": term,
                "courses_taken": len(data["courses"]),
                "credits_earned": data["total_credits"],
                "sgpa": data["sgpa"],
                "cgpa_cumulative": data["cgpa_cumulative"],
                "result_data": frappe.as_json(data["courses"])
            })

        # Generate transcript number
        transcript.transcript_number = self.generate_transcript_number()

        # Generate QR code for verification
        transcript.qr_code = self.generate_verification_qr(transcript)

        transcript.insert()
        return transcript.name

    def organize_by_semester(self):
        """Organize results by academic term"""
        semesters = {}
        cumulative_cp = 0
        cumulative_credits = 0

        # Group by term
        terms = list(set(r.academic_term for r in self.results))
        terms.sort()

        for term in terms:
            term_results = [r for r in self.results if r.academic_term == term]

            courses = []
            term_cp = 0
            term_credits = 0

            for result in term_results:
                if result.custom_result_status == "Pass":
                    term_cp += flt(result.custom_credit_points)
                    term_credits += flt(result.custom_credits)

                course_doc = frappe.get_doc("Course", result.course)
                courses.append({
                    "course_code": course_doc.custom_course_code,
                    "course_name": course_doc.course_name,
                    "credits": result.custom_credits,
                    "grade": result.custom_grade,
                    "grade_points": result.custom_grade_points,
                    "status": result.custom_result_status
                })

            cumulative_cp += term_cp
            cumulative_credits += term_credits

            sgpa = round(term_cp / term_credits, 2) if term_credits else 0
            cgpa_cumulative = round(cumulative_cp / cumulative_credits, 2) if cumulative_credits else 0

            semesters[term] = {
                "courses": courses,
                "sgpa": sgpa,
                "total_credits": term_credits,
                "cgpa_cumulative": cgpa_cumulative
            }

        return semesters

    def calculate_cgpa(self):
        """Calculate overall CGPA"""
        passed_results = [r for r in self.results if r.custom_result_status == "Pass"]

        if not passed_results:
            return 0

        total_cp = sum(flt(r.custom_credit_points) for r in passed_results)
        total_credits = sum(flt(r.custom_credits) for r in passed_results)

        return round(total_cp / total_credits, 2) if total_credits else 0

    def calculate_total_credits(self):
        """Calculate total credits earned"""
        passed_results = [r for r in self.results if r.custom_result_status == "Pass"]
        return sum(flt(r.custom_credits) for r in passed_results)

    def determine_degree_class(self, cgpa):
        """Determine degree classification based on CGPA"""
        for classification in self.DEGREE_CLASSIFICATIONS:
            if cgpa >= classification["min_cgpa"]:
                return classification["class"]
        return "Incomplete"

    def generate_transcript_number(self):
        """Generate unique transcript number"""
        import hashlib
        data = f"{self.student.name}{frappe.utils.now()}"
        return f"TR{hashlib.sha256(data.encode()).hexdigest()[:8].upper()}"

    def generate_verification_qr(self, transcript):
        """Generate QR code for online verification"""
        import qrcode
        import io

        verification_url = f"{frappe.utils.get_url()}/verify-transcript/{transcript.transcript_number}"

        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(verification_url)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")

        buffer = io.BytesIO()
        img.save(buffer, format="PNG")

        file_doc = frappe.get_doc({
            "doctype": "File",
            "file_name": f"qr_transcript_{transcript.transcript_number}.png",
            "content": buffer.getvalue(),
            "is_private": 1
        })
        file_doc.save(ignore_permissions=True)

        return file_doc.file_url

    def get_pdf(self, transcript_name):
        """Generate PDF transcript"""
        transcript = frappe.get_doc("Student Transcript", transcript_name)

        html = frappe.render_template(
            "university_erp/templates/transcript.html",
            {
                "transcript": transcript,
                "student": self.student,
                "program": frappe.get_doc("Program", transcript.program),
                "semesters": frappe.parse_json(transcript.semester_results[0].result_data) if transcript.semester_results else []
            }
        )

        return get_pdf(html, {"orientation": "Portrait"})


@frappe.whitelist()
def generate_transcript(student, transcript_type="Provisional", purpose=None):
    """API to generate transcript"""
    generator = TranscriptGenerator(student)
    return generator.generate_transcript(transcript_type, purpose)

@frappe.whitelist()
def download_transcript_pdf(transcript_name):
    """API to download transcript as PDF"""
    transcript = frappe.get_doc("Student Transcript", transcript_name)
    generator = TranscriptGenerator(transcript.student)

    pdf_content = generator.get_pdf(transcript_name)

    frappe.local.response.filename = f"Transcript_{transcript.enrollment_number}.pdf"
    frappe.local.response.filecontent = pdf_content
    frappe.local.response.type = "pdf"
```

### Week 5-6: Examinations Workspace & Reports

#### 5.1 Examinations Workspace

```json
{
    "doctype": "Workspace",
    "name": "Examinations",
    "module": "Examinations",
    "label": "Examinations",
    "icon": "clipboard",
    "is_standard": 1,
    "public": 1,
    "roles": [
        {"role": "University Admin"},
        {"role": "University Exam Cell"}
    ],
    "shortcuts": [
        {"label": "Exam Schedule", "link_to": "Exam Schedule", "type": "DocType"},
        {"label": "Hall Tickets", "link_to": "Hall Ticket", "type": "DocType"},
        {"label": "Result Entry", "link_to": "result-entry", "type": "Page"}
    ],
    "links": [
        {"type": "Card Break", "label": "Examination Planning"},
        {"type": "Link", "label": "Exam Schedule", "link_to": "Exam Schedule", "link_type": "DocType"},
        {"type": "Link", "label": "Seating Arrangement", "link_to": "Seating Arrangement", "link_type": "DocType"},

        {"type": "Card Break", "label": "Hall Tickets"},
        {"type": "Link", "label": "Hall Ticket", "link_to": "Hall Ticket", "link_type": "DocType"},
        {"type": "Link", "label": "Generate Hall Tickets", "link_to": "generate-hall-tickets", "link_type": "Page"},

        {"type": "Card Break", "label": "Results"},
        {"type": "Link", "label": "Result Entry", "link_to": "result-entry", "link_type": "Page"},
        {"type": "Link", "label": "Assessment Result", "link_to": "Assessment Result", "link_type": "DocType"},
        {"type": "Link", "label": "Apply Moderation", "link_to": "apply-moderation", "link_type": "Page"},

        {"type": "Card Break", "label": "Transcripts & Certificates"},
        {"type": "Link", "label": "Student Transcript", "link_to": "Student Transcript", "link_type": "DocType"},
        {"type": "Link", "label": "Grade Card", "link_to": "Grade Card", "link_type": "DocType"},

        {"type": "Card Break", "label": "Reports"},
        {"type": "Link", "label": "Result Analysis", "link_to": "Result Analysis Report", "link_type": "Report"},
        {"type": "Link", "label": "Course Pass Percentage", "link_to": "Course Pass Percentage", "link_type": "Report"},
        {"type": "Link", "label": "CGPA Distribution", "link_to": "CGPA Distribution Report", "link_type": "Report"}
    ]
}
```

---

## Output Checklist

### Code Deliverables
- [ ] Assessment Result override with 10-point grading
- [ ] Custom fields on Assessment Result deployed
- [ ] Hall Ticket DocType and generator
- [ ] Exam Schedule DocType
- [ ] Result Entry Tool with bulk entry
- [ ] Moderation application logic
- [ ] Student Transcript DocType and generator
- [ ] Transcript PDF generation
- [ ] QR code verification for transcripts
- [ ] Examinations workspace

### Grading Deliverables
- [ ] 10-point CBCS grading scale implemented
- [ ] Grade calculation from percentage working
- [ ] Credit points calculation working
- [ ] CGPA calculation and update working
- [ ] Degree classification logic working

### Examination Deliverables
- [ ] Hall ticket generation (single & bulk)
- [ ] Eligibility checking integrated
- [ ] Exam schedule management working
- [ ] Result entry page functional
- [ ] Moderation tools working

### Transcript Deliverables
- [ ] Semester-wise organization
- [ ] SGPA and CGPA calculation
- [ ] PDF generation working
- [ ] QR verification code generated
- [ ] Degree class determination working

### Testing Checklist
- [ ] Grade calculation accurate for all ranges
- [ ] CGPA updates after result submission
- [ ] Hall ticket shows correct eligibility
- [ ] Ineligible students flagged
- [ ] Moderation applies correctly
- [ ] Transcript shows all semesters
- [ ] PDF renders correctly
- [ ] QR code verifiable

---

## Risks & Mitigations

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Grading calculation errors | Medium | High | Extensive testing with edge cases |
| Result tampering | Low | Critical | Audit logging, permission controls |
| PDF generation failures | Low | Medium | Fallback HTML view |
| QR verification breaks | Low | Medium | Manual verification option |

---

## Dependencies for Next Phase

Phase 5 (Fees & Finance) requires:
- [ ] Hall ticket generation working (exam fees)
- [ ] Assessment results submittable
- [ ] Student records with program info

---

## Sign-off Criteria

| Criteria | Required By |
|----------|-------------|
| Grading scale verified | Controller of Exams |
| Hall ticket format approved | Registrar |
| Result entry tested | Exam Cell |
| Transcript format approved | Academic Dean |
| Security audit passed | Security Team |

---

**Previous Phase:** [Phase 3: Academics Module](phase_03_academics.md)
**Next Phase:** [Phase 5: Fees & Finance](phase_05_fees_finance.md)
